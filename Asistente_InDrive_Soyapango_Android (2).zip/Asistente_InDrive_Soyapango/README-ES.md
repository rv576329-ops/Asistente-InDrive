# Asistente de Ofertas — versión inicial

Proyecto Android de prueba para el objetivo del usuario: moto, viajes cortos en Soyapango y rango de $0.55 a $0.70 por km total.

## Qué hace
- Calcula la tarifa por kilómetro contando el trayecto hasta recoger.
- Estima combustible según km/galón y precio por galón.
- Estima una reserva de mantenimiento.
- Muestra el rango de pago objetivo y una recomendación sencilla.

## Qué NO hace todavía
- No está conectado a inDrive.
- No lee automáticamente las solicitudes.
- No envía contraofertas automáticamente.
- No garantiza ganancias ni incluye necesariamente todos los gastos.

La integración con inDrive solo debe añadirse si el proveedor ofrece y autoriza un método compatible.

## Cómo obtener un APK usando solo el teléfono
1. Descarga y descomprime este ZIP en un entorno de desarrollo en la nube compatible con Android/Gradle, o sube el contenido del proyecto a un repositorio GitHub.
2. Mantén el archivo `.github/workflows/build-apk.yml` dentro del proyecto.
3. En GitHub, abre la pestaña **Actions**, elige **Construir APK de prueba** y pulsa **Run workflow** (o haz un `push` a la rama `main`).
4. Cuando termine correctamente, abre la ejecución del workflow y descarga el artefacto `Asistente-de-Ofertas-APK`.
5. Extrae `app-debug.apk` e instálalo en tu Android solo si confías en el origen del archivo. Android puede pedir permiso para instalar desde esa fuente.

Este ZIP es el código fuente; no es el APK ya compilado. La compilación en la nube debe completarse correctamente para producir el APK.
