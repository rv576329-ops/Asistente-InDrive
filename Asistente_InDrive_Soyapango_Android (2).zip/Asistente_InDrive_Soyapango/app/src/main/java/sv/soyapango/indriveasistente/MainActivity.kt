package sv.soyapango.indriveasistente

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var fare: EditText
    private lateinit var pickupKm: EditText
    private lateinit var rideKm: EditText
    private lateinit var kmPerGallon: EditText
    private lateinit var gallonPrice: EditText
    private lateinit var maintenancePerKm: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 36)
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "Asistente de Ofertas"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF14213D.toInt())
        }
        root.addView(title)
        root.addView(label("inDrive • Moto • Soyapango"))
        root.addView(label("Analizador de prueba. No está conectado a inDrive."))

        fare = field(root, "Pago ofrecido ($)", "2.00")
        pickupKm = field(root, "Km hasta recoger al pasajero", "0.5")
        rideKm = field(root, "Km con pasajero", "2.0")
        kmPerGallon = field(root, "Rendimiento de la moto (km/galón)", "110")
        gallonPrice = field(root, "Precio de gasolina por galón ($)", "4.00")
        maintenancePerKm = field(root, "Reserva de mantenimiento por km ($)", "0.05")

        val button = Button(this).apply {
            text = "ANALIZAR OFERTA"
            setOnClickListener { analyze() }
        }
        root.addView(button, params())

        result = TextView(this).apply {
            textSize = 17f
            setTextColor(0xFF202124.toInt())
            setPadding(0, 24, 0, 12)
            text = "Introduce los datos y pulsa ANALIZAR OFERTA."
        }
        root.addView(result, params())
        root.addView(label("El rango objetivo se calcula sobre todos los kilómetros, incluida la recogida. Los gastos son estimaciones."))
        root.addView(label("La app no lee solicitudes ni envía ofertas. La integración automática depende de autorización oficial de inDrive."))
    }

    private fun label(textValue: String): TextView =
        TextView(this).apply {
            text = textValue
            textSize = 14f
            setTextColor(0xFF555B66.toInt())
            setPadding(0, 10, 0, 10)
        }

    private fun field(parent: LinearLayout, hint: String, value: String): EditText {
        parent.addView(label(hint))
        return EditText(this).also { edit ->
            edit.setSingleLine(true)
            edit.inputType = InputType.TYPE_CLASS_NUMBER or
                InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            edit.setText(value)
            edit.hint = hint
            parent.addView(edit, params())
        }
    }

    private fun params() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 8 }

    private fun number(edit: EditText): Double = edit.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: 0.0
    private fun money(v: Double) = String.format(Locale.US, "$%.2f", v)

    private fun analyze() {
        val payment = number(fare).coerceAtLeast(0.0)
        val pickup = number(pickupKm).coerceAtLeast(0.0)
        val ride = number(rideKm).coerceAtLeast(0.0)
        val totalKm = pickup + ride
        val efficiency = number(kmPerGallon)
        val price = number(gallonPrice).coerceAtLeast(0.0)
        val maintenance = number(maintenancePerKm).coerceAtLeast(0.0)

        if (totalKm <= 0.0) {
            result.text = "Introduce una distancia total mayor que cero."
            return
        }
        val rate = payment / totalKm
        val fuel = if (efficiency > 0) totalKm / efficiency * price else 0.0
        val upkeep = totalKm * maintenance
        val estimated = payment - fuel - upkeep
        val minimum = totalKm * 0.55
        val maximum = totalKm * 0.70
        val recommendation = when {
            rate < 0.55 -> "FUERA DEL RANGO: tarifa inferior a $0.55/km."
            rate <= 0.70 -> "DENTRO DEL RANGO OBJETIVO."
            else -> "SUPERIOR AL RANGO: revisa el precio y los gastos."
        }
        result.text = """
            RESULTADO

            Distancia total: ${String.format(Locale.US, "%.2f", totalKm)} km
            Tarifa: ${money(rate)} por km
            Combustible estimado: ${money(fuel)}
            Mantenimiento estimado: ${money(upkeep)}
            Resto tras estos gastos: ${money(estimated)}

            Rango de pago objetivo para este recorrido:
            ${money(minimum)} a ${money(maximum)}

            $recommendation

            Nota: no incluye todos los posibles gastos, comisiones, esperas ni el viaje de regreso.
        """.trimIndent()
    }
}
